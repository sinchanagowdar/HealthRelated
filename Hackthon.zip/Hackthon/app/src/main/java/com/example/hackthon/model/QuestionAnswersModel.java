package com.example.hackthon.model;

import androidx.annotation.NonNull;

import java.util.List;

public class QuestionAnswersModel {

    String question;
    List<String> answers;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    @NonNull
    @Override
    public String toString() {
        return question  ;
    }
}
