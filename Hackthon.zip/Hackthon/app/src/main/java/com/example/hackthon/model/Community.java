package com.example.hackthon.model;

public class Community {

    String communityName;
    String communityID;
    QuestionAnswersModel questionAnswersModel;
}
