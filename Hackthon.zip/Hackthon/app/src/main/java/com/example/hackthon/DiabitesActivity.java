package com.example.hackthon;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hackthon.model.QuestionAnswersModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DiabitesActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diabites);

        fetchDataFromFirebase();

        RMyListData[] myListData = new RMyListData[] {
                new RMyListData("Does having diabetes mean that I am at higher risk for other medical problems?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("Should I start seeing other doctors regularly, such as an eye doctor?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("How often should I test my blood sugar, and what should I do if it is too high or too low?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData(" Are there any new medications that I could use to help manage my diabetes?\n" +
                        "\n",R.drawable.ic_question_answer_black_24dp),
                new RMyListData("Does diabetes mean I have to stop eating the foods I like best?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData(" How can exercise make a difference in my diabetes?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("If I'm overweight, how many pounds do I have to lose to make a difference in my health?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("What is the importance of diet in diabetes?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData(" Are my children at increased risk for the disease?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("Do I need to take my medications even on days that I feel fine?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("Why do individuals with diabetes need to take special care of their feet?", R.drawable.ic_question_answer_black_24dp),
                new RMyListData("Why it is important for people with diabetes to be physically active?",R.drawable.ic_question_answer_black_24dp),
        };

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        RMyListAdapter adapter = new RMyListAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void fetchDataFromFirebase() {

        mDatabase = FirebaseDatabase.getInstance().getReference();

        QuestionAnswersModel questionAnswersModel = new QuestionAnswersModel();
        questionAnswersModel.setQuestion("What is blood ?");

        List<String> answers = new ArrayList<>();

        answers.add("Diabetic is fun");
        answers.add("Diabetic is fun");
        answers.add("Diabetic is fun");

        answers.add("Diabetic is not fun");
        answers.add("Diabetic is risky");
        questionAnswersModel.setAnswers(answers);

       // mDatabase.child("philips").child("community").child("diabetic").child(questionAnswersModel.getQuestion()).setValue(questionAnswersModel.getAnswers());



        DatabaseReference ref = mDatabase.child("philips").child("community").child("diabetic");

        final List<QuestionAnswersModel> questionAnswersModels = new ArrayList<>();
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                for(DataSnapshot dataSnapshot1:children){
                    Object snapshot1Value = dataSnapshot1.getValue();
                   // questionAnswersModels.add(value);
                }

                System.out.println("print list"+questionAnswersModels);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        ref.addValueEventListener(postListener);


    }
}
