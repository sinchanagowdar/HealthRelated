package com.example.hackthon;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class DiabitesActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diabites);
    }
}

