package com.example.hackthon.model;

public class Philips {


}
