package com.example.hackthon;

public class dia2 {
}
